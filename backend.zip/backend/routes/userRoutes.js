const express = require("express");
const mongoose = require("mongoose");
const User = require("../models/userModel");
const router = express.Router();

//Create account 
router.post("/",async (req, res)=>{
    const{name,email,age} = req.body;
    try {
        const userAdd = await User.create({
            name : name,
            email : email,
            age : age
        })
        res.status(201).json(userAdd);
    
    } catch (error) {
        console.log(error);
        res.send(400).json({error:error.message})
    }
});

//Show all account's details
router.get("/", async (req, res) =>{
 try {
    const showAll = await User.find(); 
    res.status(202).json(showAll);

} catch (error) {
    console.log(error);
    res.send(400).json({error:error.message})
}
})

//Show single account's details
router.get("/:id", async (req, res) =>{
    const {id} = req.params;
    try {
       const showSingle = await User.findById({_id:id}); 
       res.status(203).json(showSingle);
   
   } catch (error) {
       console.log(error);
       res.send(400).json({error:error.message})
   }
   })

   //Show single account's details
router.delete("/:id", async (req, res) =>{
    const {id} = req.params;
    try {
       const deleteSingle = await User.findByIdAndDelete({_id:id}); 
       res.status(203).json(deleteSingle);
   
   } catch (error) {
       console.log(error);
       res.send(400).json({error:error.message})
   }
   })

   //Edit details
   router.patch("/:id", async (req, res) =>{
    const {id} = req.params;
    const {name , email, age} = req.body;

    try {
       const updateDetails = await User.findByIdAndUpdate(id, req.body, {new:true}); 
       res.status(203).json(updateDetails);
   
   } catch (error) {
       console.log(error);
       res.send(400).json({error:error.message})
   }
   })
module.exports= router;